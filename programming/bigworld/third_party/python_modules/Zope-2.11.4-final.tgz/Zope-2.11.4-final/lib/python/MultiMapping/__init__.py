from _MultiMapping import *
