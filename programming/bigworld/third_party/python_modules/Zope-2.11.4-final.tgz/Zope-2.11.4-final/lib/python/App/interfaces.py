##############################################################################
#
# Copyright (c) 2005 Zope Corporation and Contributors. All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################
"""App z3 interfaces.

$Id: interfaces.py 30602 2005-06-02 11:24:21Z yuppie $
"""

from zope.interface import Attribute
from zope.interface import Interface


# XXX: might contain non-API methods and outdated comments;
#      not synced with ZopeBook API Reference;
#      based on App.Management.Navigation
class INavigation(Interface):

    """Basic navigation UI support"""

    manage = Attribute(""" """)
    manage_menu = Attribute(""" """)
    manage_top_frame = Attribute(""" """)
    manage_page_header = Attribute(""" """)
    manage_page_footer = Attribute(""" """)
    manage_form_title = Attribute("""Add Form""")
    zope_quick_start = Attribute(""" """)
    manage_copyright = Attribute(""" """)
    manage_zmi_prefs = Attribute(""" """)

    def manage_zmi_logout(REQUEST, RESPONSE):
        """Logout current user"""

INavigation.setTaggedValue('manage_page_style.css', Attribute(""" """))


# XXX: might contain non-API methods and outdated comments;
#      not synced with ZopeBook API Reference;
#      based on App.PersistentExtra.PersistentUtil
class IPersistentExtra(Interface):

    def bobobase_modification_time():
        """
        """

    def locked_in_version():
        """Was the object modified in any version?
        """

    def modified_in_version():
        """Was the object modified in this version?
        """


# XXX: might contain non-API methods and outdated comments;
#      not synced with ZopeBook API Reference;
#      based on App.Undo.UndoSupport
class IUndoSupport(Interface):

    manage_UndoForm = Attribute("""Manage Undo form""")

    def get_request_var_or_attr(name, default):
        """
        """

    def undoable_transactions(first_transaction=None,
                              last_transaction=None,
                              PrincipiaUndoBatchSize=None):
        """
        """

    def manage_undo_transactions(transaction_info=(), REQUEST=None):
        """
        """
